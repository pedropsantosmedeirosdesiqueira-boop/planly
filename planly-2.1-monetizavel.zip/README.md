# Planly 2.1
Versão com landing page de monetização, planos Grátis/Pro, CTAs, dashboard e espaço para checkout.
**Importante:** o ZIP não cobra dinheiro sozinho. Para pagamentos reais, conecte Stripe (ou outro provedor) e confirme assinaturas no servidor/webhook. Nunca coloque chaves secretas no JavaScript do navegador.
Depois, configure `CHECKOUT_MONTHLY` e `CHECKOUT_ANNUAL` com URLs públicas de checkout, quando disponíveis.
